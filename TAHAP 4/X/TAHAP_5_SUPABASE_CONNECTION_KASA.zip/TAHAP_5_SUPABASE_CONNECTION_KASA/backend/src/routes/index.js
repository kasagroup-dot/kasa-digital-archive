import { Router } from 'express';
import { env } from '../config/env.js';
import { sendSuccess } from '../utils/apiResponse.js';
import healthRoutes from './health.routes.js';

const router = Router();

router.get('/', (_req, res) => sendSuccess(res, {
  message: 'KASA Digital Archive API',
  data: {
    app: env.appName,
    company: env.companyName,
    version: env.appVersion,
    healthEndpoint: `${env.apiPrefix}/health`
  }
}));

router.use('/health', healthRoutes);

export default router;
